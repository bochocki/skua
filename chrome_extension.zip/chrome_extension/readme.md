Chrome extension starting bundle
================================

A basic starting point for all chrome extensions. Not all the files are needed for every extension, but the core basics are covered.
